import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { CheckoutForm } from "@/components/checkout/checkout-form";
import { Separator } from "@/components/ui/separator";
import { formatCurrency } from "@/lib/utils";
import { useLocation } from "wouter";

export default function CheckoutPage() {
  const { user } = useAuth();
  const [_, navigate] = useLocation();

  // Fetch cart items
  const { data: cartItems = [], isLoading } = useQuery({
    queryKey: ["/api/cart"],
    enabled: !!user,
  });

  // Calculate totals
  const subtotal = cartItems.reduce((total: number, item: any) => {
    return total + (item.product.price * item.duration);
  }, 0);
  
  const deliveryFee = subtotal > 0 ? 1500 : 0; // $15 delivery fee if cart not empty
  const total = subtotal + deliveryFee;

  // Redirect if cart is empty after loading
  useEffect(() => {
    if (!isLoading && cartItems.length === 0) {
      navigate("/");
    }
  }, [isLoading, cartItems, navigate]);

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-2xl font-bold mb-8 text-center bg-primary text-white py-3 rounded-md">
        Rental Agreement Checkout
      </h1>
      
      {/* Checkout Progress */}
      <div className="flex items-center justify-between mb-8 relative">
        <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center z-10">1</div>
        <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center z-10">2</div>
        <div className="w-8 h-8 border-2 border-primary bg-white text-primary rounded-full flex items-center justify-center z-10">3</div>
        <div className="absolute h-0.5 bg-primary left-0 right-0 top-1/2 transform -translate-y-1/2 z-0"></div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {/* User Information Form */}
          <CheckoutForm user={user} />
        </div>
        
        <div>
          {/* Order Summary */}
          <Card className="sticky top-24">
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">Order Summary</h2>
              
              <div className="space-y-4 mb-6">
                {cartItems.map((item: any) => (
                  <div key={item.id} className="flex justify-between">
                    <div>
                      <p className="font-medium">{item.product.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {item.duration} {item.duration === 1 ? 'month' : 'months'}
                      </p>
                    </div>
                    <p className="font-medium">{formatCurrency(item.product.price * item.duration / 100)}</p>
                  </div>
                ))}
              </div>
              
              <Separator className="my-4" />
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <p>Subtotal</p>
                  <p className="font-medium">{formatCurrency(subtotal / 100)}</p>
                </div>
                <div className="flex justify-between">
                  <p>Delivery & Assembly</p>
                  <p className="font-medium">{formatCurrency(deliveryFee / 100)}</p>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between text-lg font-bold">
                  <p>Total</p>
                  <p>{formatCurrency(total / 100)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
