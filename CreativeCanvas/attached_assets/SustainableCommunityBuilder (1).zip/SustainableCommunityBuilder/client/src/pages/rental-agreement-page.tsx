import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useParams, useLocation } from "wouter";
import { Loader2, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { formatDate } from "@/lib/utils";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import logoPath from "@assets/image_1745240890453.png";

export default function RentalAgreementPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<"creditCard" | "bitcoin" | "bankTransfer">("creditCard");

  // Get rental agreement data
  const { data, isLoading, error } = useQuery({
    queryKey: [`/api/rentals/${id}/agreement`],
    enabled: !!user && !!id,
  });

  const signAgreementMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/rentals/${id}/sign`, { paymentMethod });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rentals"] });
      toast({
        title: "Agreement signed",
        description: "Your rental agreement has been signed successfully",
      });
      navigate("/dashboard");
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to sign agreement",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleSign = () => {
    if (!termsAccepted) {
      toast({
        title: "Terms not accepted",
        description: "Please accept the terms and conditions to proceed",
        variant: "destructive",
      });
      return;
    }
    signAgreementMutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Error Loading Agreement</h1>
        <p className="text-muted-foreground mb-6">
          There was an error loading the rental agreement.
        </p>
        <Button onClick={() => navigate("/dashboard")}>
          <ChevronLeft className="mr-2 h-4 w-4" />
          Return to Dashboard
        </Button>
      </div>
    );
  }

  const rental = data?.rental;
  const product = data?.product;
  const userData = data?.user || user;

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center">
          <img src={logoPath} alt="QuickRent Furnish Logo" className="h-12" />
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={() => navigate("/dashboard")}>
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
        </div>
      </div>

      <h1 className="text-2xl font-bold mb-8 text-center bg-primary text-white py-3 rounded-md">
        Rental Agreement Checkout
      </h1>
      
      {/* Checkout Progress */}
      <div className="flex items-center justify-between mb-8 relative">
        <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center z-10">1</div>
        <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center z-10">2</div>
        <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center z-10">3</div>
        <div className="absolute h-0.5 bg-primary left-0 right-0 top-1/2 transform -translate-y-1/2 z-0"></div>
      </div>

      <Card>
        <CardContent className="p-6">
          <h2 className="text-xl font-bold mb-6">User Information</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block text-sm font-medium mb-1">First Name</label>
              <Input value={userData?.firstName || ""} readOnly />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Last Name</label>
              <Input value={userData?.lastName || ""} readOnly />
            </div>
          </div>
          
          <div className="mb-6">
            <label className="block text-sm font-medium mb-1">E-mail Address</label>
            <Input value={userData?.email || ""} readOnly />
          </div>
          
          <div className="mb-6">
            <label className="block text-sm font-medium mb-1">Phone Number</label>
            <Input value={userData?.phone || ""} readOnly />
          </div>
          
          <h3 className="font-bold mb-4 mt-8">Address</h3>
          
          <div className="mb-6">
            <label className="block text-sm font-medium mb-1">Street Address</label>
            <Input value={userData?.address || ""} readOnly />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <div>
              <label className="block text-sm font-medium mb-1">City</label>
              <Input value={userData?.city || ""} readOnly />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">State/Province</label>
              <Input value={userData?.state || ""} readOnly />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Zip/Postal Code</label>
              <Input value={userData?.zipCode || ""} readOnly />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Country</label>
              <Input value={userData?.country || ""} readOnly />
            </div>
          </div>
          
          <div className="flex flex-row items-start space-x-3 space-y-0 py-4 mb-6">
            <Checkbox
              checked={termsAccepted}
              onCheckedChange={(checked) => setTermsAccepted(checked === true)}
            />
            <div className="space-y-1 leading-none">
              <label className="font-medium cursor-pointer">
                I agree to the terms and conditions of this rental agreement.
              </label>
            </div>
          </div>
          
          <h3 className="font-bold mb-4">Payment Method</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <Button
              type="button"
              variant={paymentMethod === "creditCard" ? "default" : "outline"}
              className={paymentMethod === "creditCard" ? "" : "border-neutral-300"}
              onClick={() => setPaymentMethod("creditCard")}
            >
              Credit Card
            </Button>
            
            <Button
              type="button"
              variant={paymentMethod === "bitcoin" ? "default" : "outline"}
              className={paymentMethod === "bitcoin" ? "" : "border-neutral-300"}
              onClick={() => setPaymentMethod("bitcoin")}
            >
              Bitcoin
            </Button>
            
            <Button
              type="button"
              variant={paymentMethod === "bankTransfer" ? "default" : "outline"}
              className={paymentMethod === "bankTransfer" ? "" : "border-neutral-300"}
              onClick={() => setPaymentMethod("bankTransfer")}
            >
              Bank Transfer
            </Button>
          </div>
          
          <div className="flex justify-center">
            <Button
              onClick={handleSign}
              className="bg-secondary hover:bg-secondary/90 px-8"
              disabled={signAgreementMutation.isPending}
            >
              {signAgreementMutation.isPending ? "Processing..." : "Confirm & Sign"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}