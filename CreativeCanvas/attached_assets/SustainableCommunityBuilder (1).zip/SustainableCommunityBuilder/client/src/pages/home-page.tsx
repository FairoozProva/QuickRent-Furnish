import { FeaturedCategories } from "@/components/furniture/featured-categories";
import { ProductGrid } from "@/components/furniture/product-grid";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function HomePage() {
  return (
    <div>
      {/* Hero Section */}
      <div className="relative h-96 md:h-[500px]">
        <img 
          src="https://images.unsplash.com/photo-1565182999561-18d7dc61c393?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
          alt="Stylish living room with modern furniture" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-30 flex flex-col justify-center px-8 md:px-16">
          <h1 className="text-white text-3xl md:text-5xl font-bold mb-4">Smart Renting, Stylish Living</h1>
          <p className="text-white text-lg md:text-xl mb-8">Rent • Enjoy • Refresh</p>
          <Button asChild className="w-full sm:w-auto">
            <Link href="/category/sofa-set">
              Shop Now
            </Link>
          </Button>
        </div>
      </div>

      {/* Categories Section */}
      <div id="browse-categories" className="container mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold mb-8">Browse Categories</h2>
        <FeaturedCategories />
      </div>

      {/* Trending Products Section */}
      <div className="container mx-auto px-4 py-12">
        <ProductGrid
          queryKey="/api/products/trending"
          title="Trending Rentals"
          limit={4}
        />
      </div>

      {/* New Arrivals Section */}
      <div className="container mx-auto px-4 py-12">
        <ProductGrid
          queryKey="/api/products/new-arrivals"
          title="New Arrivals"
          limit={4}
        />
      </div>
    </div>
  );
}
