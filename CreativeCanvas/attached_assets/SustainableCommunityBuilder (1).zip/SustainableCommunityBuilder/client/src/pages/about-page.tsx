import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function AboutPage() {
  const { toast } = useToast();
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    message: "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setContactForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Validation
    if (!contactForm.name || !contactForm.email || !contactForm.message) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive"
      });
      return;
    }

    // Process form submission (would connect to API in a real application)
    toast({
      title: "Message sent",
      description: "Thanks for contacting us. We'll get back to you soon!"
    });

    // Reset form
    setContactForm({
      name: "",
      email: "",
      message: "",
    });
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <Card className="mb-8">
        <CardContent className="p-8">
          <h1 className="text-3xl font-bold mb-6">About</h1>
          
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/2">
              <p className="text-neutral-700 mb-4">
                Welcome to Modern House, your go-to destination for high-quality furniture rentals. At Modern House, we believe that everyone deserves to live in a beautiful, comfortable space without the commitment of purchasing expensive furniture.
              </p>
              
              <p className="text-neutral-700 mb-4">
                Our mission is simple: provide stylish, durable furniture for rent at affordable prices. Whether you're a student, young professional, or someone who loves refreshing their living space regularly, we've got you covered.
              </p>
              
              <p className="text-neutral-700 mb-4">
                Founded in 2018, we've quickly grown to become one of the most trusted furniture rental services in the country. Our extensive collection includes everything from sofas and beds to dining tables and office furniture.
              </p>
            </div>
            
            <div className="md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Modern living room with stylish furniture" 
                className="w-full h-auto rounded-lg"
              />
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Contact me</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-foreground mb-1">
                  Your name
                </label>
                <Input 
                  type="text" 
                  id="name" 
                  name="name"
                  value={contactForm.name}
                  onChange={handleInputChange}
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-foreground mb-1">
                  Your email
                </label>
                <Input 
                  type="email" 
                  id="email" 
                  name="email"
                  value={contactForm.email}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            <div className="mb-6">
              <label htmlFor="message" className="block text-sm font-medium text-foreground mb-1">
                Your message
              </label>
              <Textarea 
                id="message" 
                rows={5} 
                name="message"
                value={contactForm.message}
                onChange={handleInputChange}
              />
            </div>
            
            <Button type="submit" variant="default" className="bg-black hover:bg-black/90">
              Submit
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
