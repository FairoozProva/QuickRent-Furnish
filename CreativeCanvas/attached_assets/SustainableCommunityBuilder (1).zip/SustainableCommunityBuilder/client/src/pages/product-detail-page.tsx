import { useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Heart } from "lucide-react";
import { ProductCard } from "@/components/furniture/product-card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { formatCurrency } from "@/lib/utils";
import { useState } from "react";

export default function ProductDetailPage() {
  const { id } = useParams();
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedDuration, setSelectedDuration] = useState(3); // Default 3 months
  
  const { data: product, isLoading: productLoading } = useQuery<Product>({
    queryKey: [`/api/products/${id}`],
  });
  
  const { data: relatedProducts, isLoading: relatedLoading } = useQuery<Product[]>({
    queryKey: [`/api/products/${id}/related`],
    enabled: !!id,
  });
  
  const addToCartMutation = useMutation({
    mutationFn: async ({ productId, duration }: { productId: number, duration: number }) => {
      const res = await apiRequest("POST", "/api/cart", { productId, duration });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Added to cart",
        description: "The item has been added to your cart",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add to cart",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const addToWishlistMutation = useMutation({
    mutationFn: async (productId: number) => {
      const res = await apiRequest("POST", "/api/wishlist", { productId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wishlist"] });
      toast({
        title: "Added to wishlist",
        description: "The item has been added to your wishlist",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add to wishlist",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleAddToCart = () => {
    if (!user) {
      toast({
        title: "Please login",
        description: "You need to login to add items to cart",
        variant: "destructive",
      });
      return;
    }
    
    if (product) {
      addToCartMutation.mutate({ 
        productId: product.id, 
        duration: selectedDuration 
      });
    }
  };
  
  const handleAddToWishlist = () => {
    if (!user) {
      toast({
        title: "Please login",
        description: "You need to login to add items to wishlist",
        variant: "destructive",
      });
      return;
    }
    
    if (product) {
      addToWishlistMutation.mutate(product.id);
    }
  };
  
  if (productLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Skeleton className="h-96 w-full rounded-lg" />
          <div>
            <Skeleton className="h-10 w-3/4 mb-2" />
            <Skeleton className="h-8 w-1/4 mb-4" />
            <Skeleton className="h-24 w-full mb-6" />
            <div className="grid grid-cols-2 gap-4 mb-6">
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
            </div>
            <Skeleton className="h-12 w-full mb-4" />
            <Skeleton className="h-12 w-full" />
          </div>
        </div>
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold mb-8">Product not found</h1>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Product Image */}
        <div className="bg-white rounded-lg overflow-hidden shadow-sm">
          <img 
            src={product.imageUrl} 
            alt={product.name} 
            className="w-full h-auto"
          />
        </div>
        
        {/* Product Info */}
        <div className="bg-white rounded-lg p-6 shadow-sm">
          <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
          <p className="text-primary text-2xl font-bold mb-4">{formatCurrency(product.price / 100)}/mo</p>
          
          <div className="mb-6">
            <p className="text-neutral-500 mb-4">{product.description}</p>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              {product.dimensions && (
                <div>
                  <p className="text-sm text-neutral-500">Dimensions</p>
                  <p className="font-medium">{product.dimensions}</p>
                </div>
              )}
              
              {product.color && (
                <div>
                  <p className="text-sm text-neutral-500">Color</p>
                  <p className="font-medium">{product.color}</p>
                </div>
              )}
              
              {product.material && (
                <div>
                  <p className="text-sm text-neutral-500">Material</p>
                  <p className="font-medium">{product.material}</p>
                </div>
              )}
              
              {product.seats && (
                <div>
                  <p className="text-sm text-neutral-500">Seats</p>
                  <p className="font-medium">{product.seats}</p>
                </div>
              )}
            </div>
          </div>
          
          {/* Rental Duration */}
          <div className="mb-6">
            <h3 className="font-medium mb-3">Rental Duration</h3>
            <div className="flex flex-wrap gap-3">
              <Button 
                variant={selectedDuration === 1 ? "default" : "secondary"} 
                onClick={() => setSelectedDuration(1)}
              >
                1 Month
              </Button>
              <Button 
                variant={selectedDuration === 3 ? "default" : "secondary"} 
                onClick={() => setSelectedDuration(3)}
              >
                3 Months
              </Button>
              <Button 
                variant={selectedDuration === 6 ? "default" : "secondary"} 
                onClick={() => setSelectedDuration(6)}
              >
                6 Months
              </Button>
            </div>
          </div>
          
          {/* Add to Cart Button */}
          <Button 
            className="w-full mb-4"
            onClick={handleAddToCart}
            disabled={addToCartMutation.isPending}
          >
            Add to Cart
          </Button>
          
          {/* Wishlist Button */}
          <Button 
            variant="outline" 
            className="w-full flex items-center justify-center"
            onClick={handleAddToWishlist}
            disabled={addToWishlistMutation.isPending}
          >
            <Heart className="mr-2 h-4 w-4" /> Add to Wishlist
          </Button>
        </div>
      </div>
      
      {/* Related Products */}
      {!relatedLoading && relatedProducts && relatedProducts.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Related products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((relatedProduct) => (
              <ProductCard key={relatedProduct.id} product={relatedProduct} />
            ))}
          </div>
        </div>
      )}
      
      {/* Reviews Section */}
      <div className="mt-12">
        <Tabs defaultValue="reviews">
          <TabsList>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
            <TabsTrigger value="specifications">Specifications</TabsTrigger>
          </TabsList>
          <TabsContent value="reviews" className="mt-6">
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <div className="mb-6 pb-6 border-b border-neutral-300">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-neutral-300 flex items-center justify-center text-neutral-600">
                    <span>AB</span>
                  </div>
                  <div>
                    <h4 className="font-medium">Every apartment quality product</h4>
                    <div className="flex text-yellow-400 my-1">
                      <span>★★★★☆</span>
                    </div>
                    <p className="text-neutral-500 text-sm">
                      I've been renting this for 3 months and it's been perfect for my temporary apartment.
                      Comfortable and looks exactly like the photos.
                    </p>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-neutral-300 flex items-center justify-center text-neutral-600">
                    <span>CD</span>
                  </div>
                  <div>
                    <h4 className="font-medium">Exactly what I was looking for</h4>
                    <div className="flex text-yellow-400 my-1">
                      <span>★★★★☆</span>
                    </div>
                    <p className="text-neutral-500 text-sm">
                      The quality and comfort are excellent, and the delivery was right on schedule.
                      Would definitely recommend!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="specifications" className="mt-6">
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <ul className="space-y-2">
                {product.dimensions && (
                  <li className="flex">
                    <span className="font-medium w-32">Dimensions:</span>
                    <span>{product.dimensions}</span>
                  </li>
                )}
                {product.color && (
                  <li className="flex">
                    <span className="font-medium w-32">Color:</span>
                    <span>{product.color}</span>
                  </li>
                )}
                {product.material && (
                  <li className="flex">
                    <span className="font-medium w-32">Material:</span>
                    <span>{product.material}</span>
                  </li>
                )}
                {product.seats && (
                  <li className="flex">
                    <span className="font-medium w-32">Seats:</span>
                    <span>{product.seats}</span>
                  </li>
                )}
                <li className="flex">
                  <span className="font-medium w-32">SKU:</span>
                  <span>{product.sku}</span>
                </li>
              </ul>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
