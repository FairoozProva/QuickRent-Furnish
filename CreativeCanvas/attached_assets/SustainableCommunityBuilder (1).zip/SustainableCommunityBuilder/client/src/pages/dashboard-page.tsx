import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { DashboardSidebar } from "@/components/dashboard/dashboard-sidebar";
import { RentalCard } from "@/components/dashboard/rental-card";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate } from "@/lib/utils";
import { Rental } from "@shared/schema";
import { Loader2 } from "lucide-react";

export default function DashboardPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");
  const today = new Date();

  // Get rentals
  const { data: rentals, isLoading } = useQuery<(Rental & { product: any })[]>({
    queryKey: ["/api/rentals"],
    enabled: !!user,
  });

  // Find next due date
  const nextDueDate = rentals?.reduce((closest, rental) => {
    const endDate = new Date(rental.endDate);
    if (endDate >= today && (!closest || endDate < new Date(closest.endDate))) {
      return rental;
    }
    return closest;
  }, null as (Rental & { product: any }) | null);

  // Calculate total monthly payment
  const totalMonthlyPayment = rentals?.reduce((total, rental) => {
    return total + rental.monthlyRate;
  }, 0) || 0;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-200">
      <div className="flex flex-col md:flex-row">
        {/* Sidebar */}
        <DashboardSidebar 
          activeTab={activeTab} 
          setActiveTab={setActiveTab} 
          userName={user?.firstName || user?.username || "User"}
        />
        
        {/* Main Content */}
        <div className="flex-1 p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold">
              Welcome Back, {user?.firstName || user?.username}
            </h1>
            <p className="text-muted-foreground">Today is {formatDate(today)}</p>
          </div>
          
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardContent className="p-4">
                <h3 className="font-medium text-muted-foreground mb-2">Active Rentals</h3>
                <p className="text-2xl font-bold mb-0">{rentals?.length || 0}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <h3 className="font-medium text-muted-foreground mb-2">Next Due Date</h3>
                <p className="text-2xl font-bold mb-0 text-primary">
                  {nextDueDate ? formatDate(nextDueDate.endDate) : "N/A"}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <h3 className="font-medium text-muted-foreground mb-2">Payment</h3>
                <p className="text-2xl font-bold mb-0 text-secondary">
                  ${(totalMonthlyPayment / 100).toFixed(2)}/mo
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* Active Rentals */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">Active Furniture Rentals</h2>
              
              {rentals && rentals.length > 0 ? (
                <div className="space-y-4">
                  {rentals.map((rental) => (
                    <RentalCard key={rental.id} rental={rental} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">
                    You don't have any active rentals.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
