import { Rental } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { formatDate, formatCurrency } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { FileText } from "lucide-react";

interface RentalCardProps {
  rental: Rental & { product: any };
}

export function RentalCard({ rental }: RentalCardProps) {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  const extendRentalMutation = useMutation({
    mutationFn: async ({ rentalId, duration }: { rentalId: number, duration: number }) => {
      const res = await apiRequest("PUT", `/api/rentals/${rentalId}/extend`, { duration });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rentals"] });
      toast({
        title: "Rental extended",
        description: "Your rental has been successfully extended",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to extend rental",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleExtend = () => {
    extendRentalMutation.mutate({ 
      rentalId: rental.id, 
      duration: 1 // Extend by 1 month
    });
  };

  const handleViewAgreement = () => {
    navigate(`/rental-agreement/${rental.id}`);
  };

  return (
    <Card className="shadow-sm">
      <CardContent className="p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="h-16 w-16 rounded bg-muted mr-4 overflow-hidden">
              <img 
                src={rental.product.imageUrl} 
                alt={rental.product.name} 
                className="h-full w-full object-cover"
              />
            </div>
            <div>
              <h3 className="font-medium">{rental.product.name}</h3>
              <p className="text-sm text-muted-foreground">
                #{rental.id}
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-3 md:grid-cols-5 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground mb-1">Rental Date</p>
              <p>{formatDate(rental.startDate)}</p>
            </div>
            <div>
              <p className="text-muted-foreground mb-1">Due Date</p>
              <p>{formatDate(rental.endDate)}</p>
            </div>
            <div>
              <p className="text-muted-foreground mb-1">Monthly Fee</p>
              <p className="font-medium">{formatCurrency(rental.monthlyRate / 100)}</p>
            </div>
            <div className="text-right md:text-center">
              <Button 
                size="sm" 
                onClick={handleExtend}
                disabled={extendRentalMutation.isPending}
              >
                Extend
              </Button>
            </div>
            <div className="text-right md:text-center">
              <Button 
                size="sm"
                variant="outline"
                onClick={handleViewAgreement}
              >
                <FileText className="h-4 w-4 mr-1" />
                Agreement
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
