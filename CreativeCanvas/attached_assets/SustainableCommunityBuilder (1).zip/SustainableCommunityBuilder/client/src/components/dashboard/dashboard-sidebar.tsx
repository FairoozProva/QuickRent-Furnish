import { useState } from "react";
import { useLocation } from "wouter";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import {
  BarChart2Icon,
  HeartIcon,
  HelpCircleIcon,
  LogOutIcon,
  SettingsIcon,
  SofaIcon,
  UserCogIcon,
} from "lucide-react";

interface DashboardSidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userName: string;
}

export function DashboardSidebar({ activeTab, setActiveTab, userName }: DashboardSidebarProps) {
  const [, navigate] = useLocation();
  const { logoutMutation } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const getInitials = (name: string) => {
    return name.substring(0, 2).toUpperCase();
  };

  const handleNavigate = (path: string) => {
    if (path === "dashboard") {
      setActiveTab("dashboard");
    } else if (path === "furniture") {
      navigate("/category/sofa-set");
    } else if (path === "wishlist") {
      // Navigate to wishlist
    } else if (path === "account") {
      setActiveTab("account");
    } else if (path === "support") {
      setActiveTab("support");
    } else if (path === "logout") {
      logoutMutation.mutate();
    }
  };

  return (
    <div className={cn(
      "bg-sidebar text-sidebar-foreground md:min-h-screen",
      isCollapsed ? "w-20" : "w-full md:w-64"
    )}>
      <div className="p-4 border-b border-sidebar-border flex items-center justify-center md:justify-start">
        <Avatar className="h-12 w-12 bg-sidebar-accent">
          <AvatarFallback>{getInitials(userName)}</AvatarFallback>
        </Avatar>
        {!isCollapsed && (
          <div className="ml-3 hidden md:block">
            <h3 className="font-medium">{userName}</h3>
          </div>
        )}
      </div>
      
      <nav className="p-4">
        {!isCollapsed && (
          <h3 className="text-lg font-bold mb-4 hidden md:block">My Furniture Dashboard</h3>
        )}
        <ul className="space-y-2">
          <li>
            <Button
              variant={activeTab === "dashboard" ? "default" : "ghost"}
              className={cn(
                "w-full justify-start",
                activeTab === "dashboard" 
                  ? "bg-sidebar-primary text-sidebar-primary-foreground" 
                  : "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              )}
              onClick={() => handleNavigate("dashboard")}
            >
              <BarChart2Icon className={cn("mr-3 h-5 w-5", isCollapsed ? "mr-0 mx-auto" : "")} />
              {!isCollapsed && <span>Dashboard</span>}
            </Button>
          </li>
          <li>
            <Button
              variant="ghost"
              className="w-full justify-start hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              onClick={() => handleNavigate("furniture")}
            >
              <SofaIcon className={cn("mr-3 h-5 w-5", isCollapsed ? "mr-0 mx-auto" : "")} />
              {!isCollapsed && <span>Browse furniture</span>}
            </Button>
          </li>
          <li>
            <Button
              variant="ghost"
              className="w-full justify-start hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              onClick={() => handleNavigate("wishlist")}
            >
              <HeartIcon className={cn("mr-3 h-5 w-5", isCollapsed ? "mr-0 mx-auto" : "")} />
              {!isCollapsed && <span>Wishlist</span>}
            </Button>
          </li>
          <li>
            <Button
              variant="ghost"
              className="w-full justify-start hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              onClick={() => handleNavigate("account")}
            >
              <UserCogIcon className={cn("mr-3 h-5 w-5", isCollapsed ? "mr-0 mx-auto" : "")} />
              {!isCollapsed && <span>Account Setting</span>}
            </Button>
          </li>
          <li>
            <Button
              variant="ghost"
              className="w-full justify-start hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              onClick={() => handleNavigate("support")}
            >
              <HelpCircleIcon className={cn("mr-3 h-5 w-5", isCollapsed ? "mr-0 mx-auto" : "")} />
              {!isCollapsed && <span>Support</span>}
            </Button>
          </li>
        </ul>
        
        <div className="border-t border-sidebar-border mt-6 pt-6">
          <Button
            variant="ghost"
            className="w-full justify-start text-red-500 hover:bg-sidebar-accent hover:text-red-600"
            onClick={() => handleNavigate("logout")}
            disabled={logoutMutation.isPending}
          >
            <LogOutIcon className={cn("mr-3 h-5 w-5", isCollapsed ? "mr-0 mx-auto" : "")} />
            {!isCollapsed && <span>Log Out</span>}
          </Button>
        </div>
      </nav>
    </div>
  );
}
