import { Link } from "wouter";
import { Category } from "@shared/schema";

interface CategoryCardProps {
  category: Category;
}

export function CategoryCard({ category }: CategoryCardProps) {
  return (
    <Link href={`/category/${category.slug}`} className="flex flex-col items-center">
      <div className="h-48 w-full rounded-lg overflow-hidden mb-3">
        <img 
          src={category.imageUrl || ''} 
          alt={category.name} 
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
      </div>
      <h3 className="font-medium text-center">{category.name}</h3>
    </Link>
  );
}
