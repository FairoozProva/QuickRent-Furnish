import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { ProductCard } from "./product-card";
import { Skeleton } from "@/components/ui/skeleton";

interface ProductGridProps {
  queryKey: string;
  title: string;
  showDetails?: boolean;
  limit?: number;
}

export function ProductGrid({ queryKey, title, showDetails = false, limit }: ProductGridProps) {
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: [queryKey],
  });

  if (isLoading) {
    return (
      <div>
        <h2 className="text-2xl font-bold mb-8">{title}</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {Array(limit || 4).fill(0).map((_, i) => (
            <div key={i}>
              <Skeleton className="h-56 w-full rounded-lg mb-4" />
              <Skeleton className="h-6 w-3/4 mb-2" />
              <Skeleton className="h-4 w-1/4" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!products || products.length === 0) {
    return (
      <div>
        <h2 className="text-2xl font-bold mb-8">{title}</h2>
        <p>No products available.</p>
      </div>
    );
  }

  const displayProducts = limit ? products.slice(0, limit) : products;

  return (
    <div>
      <h2 className="text-2xl font-bold mb-8">{title}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {displayProducts.map((product) => (
          <ProductCard 
            key={product.id} 
            product={product} 
            showDetails={showDetails}
          />
        ))}
      </div>
    </div>
  );
}
