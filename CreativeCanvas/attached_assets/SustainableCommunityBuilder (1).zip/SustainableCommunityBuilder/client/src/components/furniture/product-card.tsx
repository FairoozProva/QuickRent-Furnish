import { Link } from "wouter";
import { Product } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { formatCurrency } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  showDetails?: boolean;
}

export function ProductCard({ product, showDetails = false }: ProductCardProps) {
  return (
    <Link href={`/product/${product.id}`}>
      <Card className="overflow-hidden h-full shadow-sm hover:shadow-md transition-shadow cursor-pointer">
        <div className="h-56 overflow-hidden">
          <img 
            src={product.imageUrl} 
            alt={product.name} 
            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
          />
        </div>
        <CardContent className="p-4">
          <h3 className="font-medium text-lg mb-1 line-clamp-1">{product.name}</h3>
          <p className="text-primary font-bold mb-2">{formatCurrency(product.price / 100)}/mo</p>
          
          {showDetails && (
            <p className="text-sm text-muted-foreground">
              {product.color && product.dimensions && 
                `${product.color}, ${product.dimensions}`
              }
            </p>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
