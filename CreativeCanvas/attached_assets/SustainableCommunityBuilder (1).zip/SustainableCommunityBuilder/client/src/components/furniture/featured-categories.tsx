import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import { CategoryCard } from "./category-card";
import { Skeleton } from "@/components/ui/skeleton";

export function FeaturedCategories() {
  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
        {Array(6).fill(0).map((_, i) => (
          <div key={i} className="flex flex-col items-center">
            <Skeleton className="h-48 w-full rounded-lg mb-3" />
            <Skeleton className="h-5 w-24" />
          </div>
        ))}
      </div>
    );
  }

  if (!categories || categories.length === 0) {
    return <p>No categories available.</p>;
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
      {categories.map((category) => (
        <CategoryCard key={category.id} category={category} />
      ))}
    </div>
  );
}
