import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import { CheckoutData, checkoutSchema } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { loadStripe } from "@stripe/stripe-js";

// Simulated stripe loader function since we don't have actual Stripe integration
const fakeLoadStripe = () => {
  return {
    createPaymentMethod: () => Promise.resolve({ paymentMethod: { id: 'pm_fake' } }),
  };
};

interface CheckoutFormProps {
  user: any;
}

export function CheckoutForm({ user }: CheckoutFormProps) {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [paymentMethod, setPaymentMethod] = useState<"creditCard" | "bitcoin" | "bankTransfer">("creditCard");
  
  // Prefill form with user data if available
  const form = useForm<CheckoutData>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      email: user?.email || "",
      phone: user?.phone || "",
      address: user?.address || "",
      city: user?.city || "",
      state: user?.state || "",
      zipCode: user?.zipCode || "",
      country: user?.country || "",
      termsAccepted: false,
      paymentMethod: "creditCard",
    },
  });

  const checkoutMutation = useMutation({
    mutationFn: async (data: CheckoutData) => {
      const res = await apiRequest("POST", "/api/checkout", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rentals"] });
      toast({
        title: "Order placed successfully",
        description: "Your furniture rental order has been placed!",
      });
      navigate("/dashboard");
    },
    onError: (error: Error) => {
      toast({
        title: "Checkout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: CheckoutData) => {
    try {
      // Include the selected payment method
      const checkoutData = {
        ...data,
        paymentMethod,
      };
      
      // Process checkout
      checkoutMutation.mutate(checkoutData);
    } catch (error) {
      console.error("Checkout error:", error);
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-xl font-bold mb-6">User Information</h2>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>E-mail Address</FormLabel>
                    <FormControl>
                      <Input type="email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input type="tel" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <h3 className="font-bold mb-4 mt-8">Address</h3>
            
            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Street Address</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <FormField
                control={form.control}
                name="city"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>City</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="state"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>State/Province</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="zipCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Zip/Postal Code</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="country"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Country</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="termsAccepted"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 py-4">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>
                      I agree to the terms and conditions of this rental agreement.
                    </FormLabel>
                    <FormMessage />
                  </div>
                </FormItem>
              )}
            />
            
            <h3 className="font-bold mb-4">Payment Method</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <Button
                type="button"
                variant={paymentMethod === "creditCard" ? "default" : "outline"}
                className={paymentMethod === "creditCard" ? "" : "border-neutral-300"}
                onClick={() => setPaymentMethod("creditCard")}
              >
                Credit Card
              </Button>
              
              <Button
                type="button"
                variant={paymentMethod === "bitcoin" ? "default" : "outline"}
                className={paymentMethod === "bitcoin" ? "" : "border-neutral-300"}
                onClick={() => setPaymentMethod("bitcoin")}
              >
                Bitcoin
              </Button>
              
              <Button
                type="button"
                variant={paymentMethod === "bankTransfer" ? "default" : "outline"}
                className={paymentMethod === "bankTransfer" ? "" : "border-neutral-300"}
                onClick={() => setPaymentMethod("bankTransfer")}
              >
                Bank Transfer
              </Button>
            </div>
            
            <div className="flex justify-center">
              <Button
                type="submit"
                className="bg-secondary hover:bg-secondary/90 px-8"
                disabled={checkoutMutation.isPending}
              >
                {checkoutMutation.isPending ? "Processing..." : "Check In 4 Easy"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
