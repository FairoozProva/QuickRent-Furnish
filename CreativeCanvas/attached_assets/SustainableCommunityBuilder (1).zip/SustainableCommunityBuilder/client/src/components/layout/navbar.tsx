import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Logo } from "@/components/ui/logo";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Search,
  Heart,
  ShoppingCart,
  User,
  Menu,
  X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";

export default function Navbar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // Get wishlist count
  const { data: wishlistItems = [] } = useQuery<any[]>({
    queryKey: ["/api/wishlist"],
    enabled: !!user,
  });
  
  // Get cart count
  const { data: cartItems = [] } = useQuery<any[]>({
    queryKey: ["/api/cart"],
    enabled: !!user,
  });
  
  const wishlistCount = wishlistItems?.length || 0;
  const cartCount = cartItems?.length || 0;
  
  const navLinks = [
    { name: "Home", href: "/" },
    { name: "Shop", href: "/#browse-categories" },
    { name: "About", href: "/about" },
  ];

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/" className="flex items-center">
          <Logo />
        </Link>
        
        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          <nav className="flex items-center space-x-6">
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                href={link.href}
                className={`hover:text-primary font-medium ${
                  location === link.href ? "text-primary" : "text-foreground"
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon">
              <Search className="h-5 w-5" />
            </Button>
            
            <Button variant="ghost" size="icon" asChild>
              <Link href={user ? "/dashboard" : "/auth"}>
                <div className="relative">
                  <Heart className="h-5 w-5" />
                  {user && wishlistCount > 0 && (
                    <Badge variant="default" className="absolute -top-2 -right-2 h-4 w-4 p-0 flex items-center justify-center">
                      {wishlistCount}
                    </Badge>
                  )}
                </div>
              </Link>
            </Button>
            
            <Button variant="ghost" size="icon" asChild>
              <Link href={user ? "/checkout" : "/auth"}>
                <div className="relative">
                  <ShoppingCart className="h-5 w-5" />
                  {user && cartCount > 0 && (
                    <Badge variant="default" className="absolute -top-2 -right-2 h-4 w-4 p-0 flex items-center justify-center">
                      {cartCount}
                    </Badge>
                  )}
                </div>
              </Link>
            </Button>
            
            {user ? (
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="icon" asChild>
                  <Link href="/dashboard">
                    <User className="h-5 w-5" />
                  </Link>
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => logoutMutation.mutate()}
                  disabled={logoutMutation.isPending}
                >
                  Logout
                </Button>
              </div>
            ) : (
              <Button variant="ghost" size="icon" asChild>
                <Link href="/auth">
                  <User className="h-5 w-5" />
                </Link>
              </Button>
            )}
          </div>
        </div>
        
        {/* Mobile Menu Button */}
        <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="sm:max-w-sm w-full">
            <SheetHeader>
              <SheetTitle>
                <Logo size="sm" />
              </SheetTitle>
              <SheetDescription>
                Smart furniture rental with QuickRent Furnish
              </SheetDescription>
            </SheetHeader>
            <div className="py-4">
              <nav className="flex flex-col space-y-4">
                {navLinks.map((link) => (
                  <Link 
                    key={link.name} 
                    href={link.href}
                    onClick={() => setIsMenuOpen(false)}
                    className={`px-2 py-1 rounded hover:bg-muted ${
                      location === link.href ? "text-primary font-medium" : "text-foreground"
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
                
                {user ? (
                  <>
                    <Link 
                      href="/dashboard" 
                      onClick={() => setIsMenuOpen(false)}
                      className="px-2 py-1 rounded hover:bg-muted flex items-center"
                    >
                      <User className="h-4 w-4 mr-2" />
                      Dashboard
                    </Link>
                    <Link 
                      href="/checkout" 
                      onClick={() => setIsMenuOpen(false)}
                      className="px-2 py-1 rounded hover:bg-muted flex items-center"
                    >
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Cart
                      {cartCount > 0 && (
                        <Badge variant="default" className="ml-2">
                          {cartCount}
                        </Badge>
                      )}
                    </Link>
                    <button
                      className="px-2 py-1 rounded hover:bg-muted text-left text-destructive"
                      onClick={() => {
                        logoutMutation.mutate();
                        setIsMenuOpen(false);
                      }}
                      disabled={logoutMutation.isPending}
                    >
                      Logout
                    </button>
                  </>
                ) : (
                  <Link 
                    href="/auth" 
                    onClick={() => setIsMenuOpen(false)}
                    className="px-2 py-1 rounded hover:bg-muted"
                  >
                    Login / Register
                  </Link>
                )}
              </nav>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
