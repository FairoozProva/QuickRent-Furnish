import { Link } from "wouter";
import { Logo } from "@/components/ui/logo";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Layers } from "lucide-react";
import { 
  FaFacebookF,
  FaTwitter,
  FaInstagram,
  FaPinterestP,
} from "react-icons/fa";

export default function Footer() {
  const quickLinks = [
    { name: "Home", href: "/" },
    { name: "Shop", href: "/category/sofa-set" },
    { name: "About Us", href: "/about" },
    { name: "Contact", href: "/about" },
    { name: "FAQs", href: "#" },
  ];

  const customerServiceLinks = [
    { name: "My Account", href: "/dashboard" },
    { name: "Track Order", href: "#" },
    { name: "Return Policy", href: "#" },
    { name: "Shipping Info", href: "#" },
    { name: "Help & Support", href: "#" },
  ];

  const legalLinks = [
    { name: "Privacy Policy", href: "#" },
    { name: "Terms of Service", href: "#" },
    { name: "Cookie Policy", href: "#" },
  ];

  return (
    <footer className="bg-white pt-12 pb-8 border-t border-neutral-200">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <Link href="/" className="flex items-center mb-4">
              <Logo />
            </Link>
            <p className="text-muted-foreground mb-4">
              Smart furniture rental for modern living. Experience the joy of stylish 
              furniture without the commitment.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-muted-foreground hover:text-primary">
                <FaFacebookF />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary">
                <FaTwitter />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary">
                <FaInstagram />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary">
                <FaPinterestP />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href}
                    className="text-muted-foreground hover:text-primary"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Customer Service</h3>
            <ul className="space-y-2">
              {customerServiceLinks.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href}
                    className="text-muted-foreground hover:text-primary"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Newsletter</h3>
            <p className="text-muted-foreground mb-4">
              Subscribe to receive updates, access to exclusive deals, and more.
            </p>
            <form className="flex" onSubmit={(e) => e.preventDefault()}>
              <Input 
                type="email" 
                placeholder="Your email address" 
                className="rounded-r-none"
              />
              <Button type="submit" className="rounded-l-none">
                <Layers className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-neutral-200 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-muted-foreground mb-4 md:mb-0">
            © {new Date().getFullYear()} QuickRent Furnish. All rights reserved.
          </p>
          <div className="flex flex-wrap justify-center space-x-6">
            {legalLinks.map((link) => (
              <Link 
                key={link.name} 
                href={link.href}
                className="text-muted-foreground hover:text-primary text-sm"
              >
                {link.name}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
