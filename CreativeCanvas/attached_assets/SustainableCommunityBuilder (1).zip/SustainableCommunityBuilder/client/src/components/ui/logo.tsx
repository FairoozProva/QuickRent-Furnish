import { cn } from "@/lib/utils";
import logoImage from "../../assets/logo.png";

interface LogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

export function Logo({ className, size = "md" }: LogoProps) {
  const sizes = {
    sm: "h-6",
    md: "h-8",
    lg: "h-10",
  };

  return (
    <div className={cn("flex items-center", className)}>
      <div className={cn("mr-2 flex items-center justify-center", sizes[size])}>
        <img 
          src={logoImage} 
          alt="QuickRent Furnish Logo" 
          className={cn(sizes[size], "object-contain")}
        />
      </div>
      <span className={cn("font-bold text-foreground", {
        "text-sm": size === "sm",
        "text-lg": size === "md",
        "text-xl": size === "lg",
      })}>QUICKRENT FURNISH</span>
    </div>
  );
}
