import {
  type User, type InsertUser,
  type Category, type InsertCategory,
  type Product, type InsertProduct,
  type Rental, type InsertRental,
  type WishlistItem, type InsertWishlist,
  type CartItem, type InsertCart,
  UserModel, CategoryModel, ProductModel,
  RentalModel, WishlistModel, CartModel
} from "../shared/models";
import session from "express-session";
import createMemoryStore from "memorystore";
import { Types } from "mongoose";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | null>;
  getUserByUsername(username: string): Promise<User | null>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<User>): Promise<User | null>;

  // Category methods
  getCategories(): Promise<Category[]>;
  getCategory(id: string): Promise<Category | null>;
  getCategoryBySlug(slug: string): Promise<Category | null>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Product methods
  getProducts(filters?: { 
    categoryId?: string, 
    isTrending?: boolean, 
    isNewArrival?: boolean 
  }): Promise<Product[]>;
  getProduct(id: string): Promise<Product | null>;
  getProductBySku(sku: string): Promise<Product | null>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Rental methods
  getRentals(userId: string): Promise<Rental[]>;
  getRental(id: string): Promise<Rental | null>;
  createRental(rental: InsertRental): Promise<Rental>;
  updateRental(id: string, rental: Partial<Rental>): Promise<Rental | null>;

  // Wishlist methods
  getWishlistItems(userId: string): Promise<WishlistItem[]>;
  addToWishlist(wishlistItem: InsertWishlist): Promise<WishlistItem>;
  removeFromWishlist(userId: string, productId: string): Promise<void>;

  // Cart methods
  getCartItems(userId: string): Promise<CartItem[]>;
  addToCart(cartItem: InsertCart): Promise<CartItem>;
  updateCartItem(userId: string, productId: string, duration: number): Promise<CartItem | null>;
  removeFromCart(userId: string, productId: string): Promise<void>;
  clearCart(userId: string): Promise<void>;

  sessionStore: session.Store;
}

export class MongoDBStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    if (!process.env.SESSION_SECRET) {
      throw new Error('SESSION_SECRET must be set in environment variables');
    }
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
      secret: process.env.SESSION_SECRET
    });
  }

  // User methods
  async getUser(id: string): Promise<User | null> {
    try {
      return await UserModel.findById(id);
    } catch (error) {
      console.error("Error getting user:", error);
      return null;
    }
  }

  async getUserByUsername(username: string): Promise<User | null> {
    try {
      return await UserModel.findOne({ username });
    } catch (error) {
      console.error("Error getting user by username:", error);
      return null;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const user = new UserModel(insertUser);
      return await user.save();
    } catch (error) {
      console.error("Error creating user:", error);
      throw error;
    }
  }

  async updateUser(id: string, userData: Partial<User>): Promise<User | null> {
    try {
      return await UserModel.findByIdAndUpdate(id, userData, { new: true });
    } catch (error) {
      console.error("Error updating user:", error);
      return null;
    }
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    try {
      return await CategoryModel.find();
    } catch (error) {
      console.error("Error getting categories:", error);
      return [];
    }
  }

  async getCategory(id: string): Promise<Category | null> {
    try {
      return await CategoryModel.findById(id);
    } catch (error) {
      console.error("Error getting category:", error);
      return null;
    }
  }

  async getCategoryBySlug(slug: string): Promise<Category | null> {
    try {
      return await CategoryModel.findOne({ slug });
    } catch (error) {
      console.error("Error getting category by slug:", error);
      return null;
    }
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    try {
      const category = new CategoryModel(insertCategory);
      return await category.save();
    } catch (error) {
      console.error("Error creating category:", error);
      throw error;
    }
  }

  // Product methods
  async getProducts(filters?: {
    categoryId?: string,
    isTrending?: boolean,
    isNewArrival?: boolean
  }): Promise<Product[]> {
    try {
      let query = ProductModel.find();
      
      if (filters) {
        if (filters.categoryId) {
          query = query.where('categoryId').equals(new Types.ObjectId(filters.categoryId));
        }
        
        if (filters.isTrending !== undefined) {
          query = query.where('isTrending').equals(filters.isTrending);
        }
        
        if (filters.isNewArrival !== undefined) {
          query = query.where('isNewArrival').equals(filters.isNewArrival);
        }
      }
      
      return await query.exec();
    } catch (error) {
      console.error("Error getting products:", error);
      return [];
    }
  }

  async getProduct(id: string): Promise<Product | null> {
    try {
      return await ProductModel.findById(id);
    } catch (error) {
      console.error("Error getting product:", error);
      return null;
    }
  }

  async getProductBySku(sku: string): Promise<Product | null> {
    try {
      return await ProductModel.findOne({ sku });
    } catch (error) {
      console.error("Error getting product by SKU:", error);
      return null;
    }
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    try {
      const product = new ProductModel({
        ...insertProduct,
        // Convert string ID to ObjectId
        categoryId: new Types.ObjectId(insertProduct.categoryId)
      });
      return await product.save();
    } catch (error) {
      console.error("Error creating product:", error);
      throw error;
    }
  }

  // Rental methods
  async getRentals(userId: string): Promise<Rental[]> {
    try {
      return await RentalModel.find({ userId: new Types.ObjectId(userId) });
    } catch (error) {
      console.error("Error getting rentals:", error);
      return [];
    }
  }

  async getRental(id: string): Promise<Rental | null> {
    try {
      return await RentalModel.findById(id);
    } catch (error) {
      console.error("Error getting rental:", error);
      return null;
    }
  }

  async createRental(insertRental: InsertRental): Promise<Rental> {
    try {
      const rental = new RentalModel({
        ...insertRental,
        userId: new Types.ObjectId(insertRental.userId),
        productId: new Types.ObjectId(insertRental.productId)
      });
      return await rental.save();
    } catch (error) {
      console.error("Error creating rental:", error);
      throw error;
    }
  }

  async updateRental(id: string, rentalData: Partial<Rental>): Promise<Rental | null> {
    try {
      return await RentalModel.findByIdAndUpdate(id, rentalData, { new: true });
    } catch (error) {
      console.error("Error updating rental:", error);
      return null;
    }
  }

  // Wishlist methods
  async getWishlistItems(userId: string): Promise<WishlistItem[]> {
    try {
      return await WishlistModel.find({ userId: new Types.ObjectId(userId) });
    } catch (error) {
      console.error("Error getting wishlist items:", error);
      return [];
    }
  }

  async addToWishlist(insertWishlistItem: InsertWishlist): Promise<WishlistItem> {
    try {
      // Check if item already exists
      const existingItem = await WishlistModel.findOne({
        userId: new Types.ObjectId(insertWishlistItem.userId),
        productId: new Types.ObjectId(insertWishlistItem.productId)
      });

      if (existingItem) {
        return existingItem;
      }

      // Create new wishlist item
      const wishlistItem = new WishlistModel({
        userId: new Types.ObjectId(insertWishlistItem.userId),
        productId: new Types.ObjectId(insertWishlistItem.productId)
      });
      
      return await wishlistItem.save();
    } catch (error) {
      console.error("Error adding to wishlist:", error);
      throw error;
    }
  }

  async removeFromWishlist(userId: string, productId: string): Promise<void> {
    try {
      await WishlistModel.deleteOne({
        userId: new Types.ObjectId(userId),
        productId: new Types.ObjectId(productId)
      });
    } catch (error) {
      console.error("Error removing from wishlist:", error);
      throw error;
    }
  }

  // Cart methods
  async getCartItems(userId: string): Promise<CartItem[]> {
    try {
      return await CartModel.find({ userId: new Types.ObjectId(userId) });
    } catch (error) {
      console.error("Error getting cart items:", error);
      return [];
    }
  }

  async addToCart(insertCartItem: InsertCart): Promise<CartItem> {
    try {
      // Check if item already exists
      const existingItem = await CartModel.findOne({
        userId: new Types.ObjectId(insertCartItem.userId),
        productId: new Types.ObjectId(insertCartItem.productId)
      });

      if (existingItem) {
        // Update duration if exists
        return await this.updateCartItem(
          insertCartItem.userId,
          insertCartItem.productId,
          insertCartItem.duration || 3
        ) as CartItem;
      }

      // Create new cart item
      const cartItem = new CartModel({
        userId: new Types.ObjectId(insertCartItem.userId),
        productId: new Types.ObjectId(insertCartItem.productId),
        duration: insertCartItem.duration || 3
      });
      
      return await cartItem.save();
    } catch (error) {
      console.error("Error adding to cart:", error);
      throw error;
    }
  }

  async updateCartItem(userId: string, productId: string, duration: number): Promise<CartItem | null> {
    try {
      return await CartModel.findOneAndUpdate(
        {
          userId: new Types.ObjectId(userId),
          productId: new Types.ObjectId(productId)
        },
        { duration },
        { new: true }
      );
    } catch (error) {
      console.error("Error updating cart item:", error);
      return null;
    }
  }

  async removeFromCart(userId: string, productId: string): Promise<void> {
    try {
      await CartModel.deleteOne({
        userId: new Types.ObjectId(userId),
        productId: new Types.ObjectId(productId)
      });
    } catch (error) {
      console.error("Error removing from cart:", error);
      throw error;
    }
  }

  async clearCart(userId: string): Promise<void> {
    try {
      await CartModel.deleteMany({ userId: new Types.ObjectId(userId) });
    } catch (error) {
      console.error("Error clearing cart:", error);
      throw error;
    }
  }
}

// Create a new MongoDB storage instance
export const storage = new MongoDBStorage();