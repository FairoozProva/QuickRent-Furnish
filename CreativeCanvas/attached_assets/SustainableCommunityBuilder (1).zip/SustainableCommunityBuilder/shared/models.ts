import mongoose, { Document, Schema } from 'mongoose';
import { z } from 'zod';

// User Schema
export interface User extends Document {
  username: string;
  password: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  country?: string;
  createdAt: Date;
}

const userSchema = new Schema<User>({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  firstName: { type: String },
  lastName: { type: String },
  email: { type: String },
  phone: { type: String },
  address: { type: String },
  city: { type: String },
  state: { type: String },
  zipCode: { type: String },
  country: { type: String },
  createdAt: { type: Date, default: Date.now }
});

// Category Schema
export interface Category extends Document {
  name: string;
  slug: string;
  imageUrl?: string;
  createdAt: Date;
}

const categorySchema = new Schema<Category>({
  name: { type: String, required: true },
  slug: { type: String, required: true, unique: true },
  imageUrl: { type: String },
  createdAt: { type: Date, default: Date.now }
});

// Product Schema
export interface Product extends Document {
  name: string;
  sku: string;
  description?: string;
  price: number;
  categoryId: mongoose.Types.ObjectId;
  imageUrl?: string;
  dimensions?: string;
  color?: string;
  material?: string;
  seats?: number;
  isTrending: boolean;
  isNewArrival: boolean;
  createdAt: Date;
}

const productSchema = new Schema<Product>({
  name: { type: String, required: true },
  sku: { type: String, required: true, unique: true },
  description: { type: String },
  price: { type: Number, required: true },
  categoryId: { type: Schema.Types.ObjectId, ref: 'Category' },
  imageUrl: { type: String },
  dimensions: { type: String },
  color: { type: String },
  material: { type: String },
  seats: { type: Number },
  isTrending: { type: Boolean, default: false },
  isNewArrival: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

// Rental Schema
export interface Rental extends Document {
  userId: mongoose.Types.ObjectId;
  productId: mongoose.Types.ObjectId;
  duration: number;
  startDate: Date;
  endDate: Date;
  monthlyRate: number;
  status: string;
  createdAt: Date;
}

const rentalSchema = new Schema<Rental>({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  productId: { type: Schema.Types.ObjectId, ref: 'Product', required: true },
  duration: { type: Number, required: true },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  monthlyRate: { type: Number, required: true },
  status: { type: String, default: 'active' },
  createdAt: { type: Date, default: Date.now }
});

// Wishlist Schema
export interface WishlistItem extends Document {
  userId: mongoose.Types.ObjectId;
  productId: mongoose.Types.ObjectId;
  createdAt: Date;
}

const wishlistSchema = new Schema<WishlistItem>({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  productId: { type: Schema.Types.ObjectId, ref: 'Product', required: true },
  createdAt: { type: Date, default: Date.now }
});

// Cart Schema
export interface CartItem extends Document {
  userId: mongoose.Types.ObjectId;
  productId: mongoose.Types.ObjectId;
  duration: number;
  createdAt: Date;
}

const cartSchema = new Schema<CartItem>({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  productId: { type: Schema.Types.ObjectId, ref: 'Product', required: true },
  duration: { type: Number, default: 3 },
  createdAt: { type: Date, default: Date.now }
});

// Mongoose Models
export const UserModel = mongoose.model<User>('User', userSchema);
export const CategoryModel = mongoose.model<Category>('Category', categorySchema);
export const ProductModel = mongoose.model<Product>('Product', productSchema);
export const RentalModel = mongoose.model<Rental>('Rental', rentalSchema);
export const WishlistModel = mongoose.model<WishlistItem>('Wishlist', wishlistSchema);
export const CartModel = mongoose.model<CartItem>('Cart', cartSchema);

// Zod Schemas for Validation
export const insertUserSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  email: z.string().email("Please enter a valid email address").optional(),
  phone: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zipCode: z.string().optional(),
  country: z.string().optional()
});

export const insertCategorySchema = z.object({
  name: z.string().min(2, "Category name is required"),
  slug: z.string().min(2, "Slug is required"),
  imageUrl: z.string().optional()
});

export const insertProductSchema = z.object({
  name: z.string().min(2, "Product name is required"),
  sku: z.string().min(2, "SKU is required"),
  description: z.string().optional(),
  price: z.number().positive("Price must be a positive number"),
  categoryId: z.string().min(1, "Category is required"),
  imageUrl: z.string().optional(),
  dimensions: z.string().optional(),
  color: z.string().optional(),
  material: z.string().optional(),
  seats: z.number().optional(),
  isTrending: z.boolean().optional(),
  isNewArrival: z.boolean().optional()
});

export const insertRentalSchema = z.object({
  userId: z.string().min(1, "User ID is required"),
  productId: z.string().min(1, "Product ID is required"),
  duration: z.number().positive("Duration must be a positive number"),
  startDate: z.date(),
  endDate: z.date(),
  monthlyRate: z.number().positive("Monthly rate must be a positive number"),
  status: z.string().optional()
});

export const insertWishlistSchema = z.object({
  userId: z.string().min(1, "User ID is required"),
  productId: z.string().min(1, "Product ID is required")
});

export const insertCartSchema = z.object({
  userId: z.string().min(1, "User ID is required"),
  productId: z.string().min(1, "Product ID is required"),
  duration: z.number().positive("Duration must be a positive number").optional()
});

// Extended schemas for frontend validation
export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters")
});

export const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(6, "Password must be at least 6 characters")
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"]
});

export const checkoutSchema = z.object({
  firstName: z.string().min(2, "First name is required"),
  lastName: z.string().min(2, "Last name is required"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  address: z.string().min(5, "Address is required"),
  city: z.string().min(2, "City is required"),
  state: z.string().min(2, "State/Province is required"),
  zipCode: z.string().min(5, "ZIP/Postal code is required"),
  country: z.string().min(2, "Country is required"),
  termsAccepted: z.boolean().refine(val => val === true, {
    message: "You must accept the terms and conditions"
  }),
  paymentMethod: z.enum(["creditCard", "bitcoin", "bankTransfer"])
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type InsertRental = z.infer<typeof insertRentalSchema>;
export type InsertWishlist = z.infer<typeof insertWishlistSchema>;
export type InsertCart = z.infer<typeof insertCartSchema>;
export type LoginData = z.infer<typeof loginSchema>;
export type RegisterData = z.infer<typeof registerSchema>;
export type CheckoutData = z.infer<typeof checkoutSchema>;